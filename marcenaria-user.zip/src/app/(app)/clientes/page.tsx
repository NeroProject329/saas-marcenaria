import GlassCard from "@/components/ui/GlassCard";
import PageHeader from "@/components/layout/PageHeader";

export default function ClientesPage() {
  return (
    <div className="space-y-4">
      <PageHeader
        title="Clientes"
        subtitle="Cliente/Fornecedor/Both + histórico (timeline)."
        badge={{ label: "M4/M5", tone: "ink" }}
      />
      <GlassCard className="p-4">
        <div className="text-sm font-semibold text-[color:var(--muted)]">
          Placeholder premium (M1).
        </div>
      </GlassCard>
    </div>
  );
}