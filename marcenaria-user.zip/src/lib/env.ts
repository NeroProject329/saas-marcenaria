export const API_URL =
  process.env.NEXT_PUBLIC_API_URL?.trim() ||
  "http://localhost:3001";