"use client";

import { useMemo, useRef, useState } from "react";
import {
  TrendingUp,
  Wallet,
  Hammer,
  Users,
  ArrowUpRight,
  ArrowDownCircle,
  ArrowUpCircle,
  FileText,
  Boxes,
} from "lucide-react";

import PageHeader from "@/components/layout/PageHeader";
import GlassCard from "@/components/ui/GlassCard";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import Skeleton from "@/components/ui/Skeleton";
import Tabs from "@/components/ui/Tabs";
import KpiCard from "@/components/ui/KpiCard";
import DataTable from "@/components/ui/DataTable";
import StatusPill from "@/components/ui/StatusPill";
import { useGsapStagger } from "@/motion/useGsapStagger";
import { moneyBRLFromCents, isoToBR } from "@/lib/format";
import WaveMiniCard from "@/components/charts/WaveMiniCard";

type Section = "overview" | "finance" | "sales" | "stock";
type FinanceTab =
  | "medias"
  | "breakeven"
  | "dfc"
  | "receber"
  | "pagar"
  | "dre"
  | "projetado"
  | "operacional"
  | "insights";

export default function DashboardClient() {
  const wrapRef = useRef<HTMLDivElement | null>(null);

  useGsapStagger(wrapRef, {
    selector: "[data-stagger]",
    y: 16,
    duration: 0.55,
    stagger: 0.06,
  });

  // abas “do print”
  const sections = useMemo(
    () => [
      { key: "overview", label: "Visão Geral" },
      { key: "finance", label: "Financeiro" },
      { key: "sales", label: "Vendas" },
      { key: "stock", label: "Estoque" },
    ],
    []
  );

  const [section, setSection] = useState<Section>("overview");

  // abas “do legado” (dentro do Financeiro)
  const financeTabs = useMemo(
    () => [
      { key: "medias", label: "Médias" },
      { key: "breakeven", label: "Break-even" },
      { key: "dfc", label: "DFC" },
      { key: "receber", label: "Receber" },
      { key: "pagar", label: "Pagar" },
      { key: "dre", label: "DRE" },
      { key: "projetado", label: "Fluxo projetado" },
      { key: "operacional", label: "Operacional" },
      { key: "insights", label: "Insights" },
    ],
    []
  );

  const [financeTab, setFinanceTab] = useState<FinanceTab>("medias");

  const kpis = useMemo(
    () => [
      {
        label: "Saldo do mês",
        value: moneyBRLFromCents(0),
        icon: Wallet,
        hint: "Placeholder (dados reais no M5)",
        tone: "brand" as const,
      },
      {
        label: "Vendas",
        value: "0",
        icon: TrendingUp,
        hint: "Pedidos + orçamentos",
        tone: "success" as const,
      },
      {
        label: "Produção",
        value: "0",
        icon: Hammer,
        hint: "Em produção / pronto",
        tone: "wood" as const,
      },
      {
        label: "Clientes",
        value: "0",
        icon: Users,
        hint: "Base total",
        tone: "neutral" as const,
      },
    ],
    []
  );

  // mocks (shape real do financeiro)
  const recvRows = useMemo(
    () => [
      {
        id: "r1",
        dueDate: new Date().toISOString(),
        client: "Cliente X",
        desc: "Pedido #123",
        amountCents: 250000,
        status: "ABERTO",
      },
      {
        id: "r2",
        dueDate: new Date().toISOString(),
        client: "Cliente Y",
        desc: "Pedido #124",
        amountCents: 180000,
        status: "PAGO",
      },
    ],
    []
  );

  const payRows = useMemo(
    () => [
      {
        id: "p1",
        dueDate: new Date().toISOString(),
        supplier: "Fornecedor A",
        desc: "Madeira (NF 123) 1/3",
        amountCents: 80000,
        status: "ABERTO",
      },
      {
        id: "p2",
        dueDate: new Date().toISOString(),
        supplier: "Fornecedor A",
        desc: "Madeira (NF 123) 2/3",
        amountCents: 80000,
        status: "PAGO",
      },
    ],
    []
  );

  const chartPoints = useMemo(
  () => [
    { label: "Jan", valueCents: 2100000 },
    { label: "Fev", valueCents: 2400000 },
    { label: "Mar", valueCents: 1800000 },
    { label: "Abr", valueCents: 2600000 },
    { label: "Mai", valueCents: 3200000 },
    { label: "Jun", valueCents: 2900000 },
    { label: "Jul", valueCents: 3600000 },
    { label: "Ago", valueCents: 4100000 },
  ],
  []
);

  return (
    <div ref={wrapRef} className="space-y-5">
      {/* Header + Tabs “print” */}
      <div data-stagger>
        <PageHeader
          title="Dashboard"
          subtitle="Base premium alinhada com a referência. Dados reais entram no M5."
          badge={{ label: "Premium", tone: "brand" }}
          right={
            <Tabs
              items={sections}
              value={section}
              onChange={(k) => setSection(k as Section)}
              className="max-w-full"
            />
          }
        />
      </div>

      {/* HERO (sempre aparece na Visão Geral, igual print) */}
      {section === "overview" ? (
        <section data-stagger>
          <div className="relative overflow-hidden rounded-[34px] border border-black/10 bg-[color:var(--brand)] shadow-[var(--shadow-card-2)]">
            <div className="absolute inset-0 opacity-35">
              <div className="absolute -left-24 -top-24 h-80 w-80 rounded-full bg-white/55 blur-3xl" />
              <div className="absolute -right-24 -bottom-24 h-80 w-80 rounded-full bg-black/10 blur-3xl" />
            </div>

            <div className="relative grid gap-6 p-5 sm:p-7 lg:grid-cols-[1.12fr_0.88fr] lg:items-center">
              <div className="space-y-3">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone="ink">Hero</Badge>
                  <Badge tone="wood">Glass + Pills</Badge>
                  <Badge tone="ink">Lux</Badge>
                </div>

                <h2 className="font-display text-2xl font-black tracking-tight text-[color:var(--ink)] sm:text-3xl">
                  Projetos em destaque
                </h2>

                <p className="max-w-xl text-sm font-semibold text-black/65">
                  No M6 este hero vira carrossel real com imagens dos seus projetos/produtos e animação GSAP.
                </p>

                <div className="flex flex-wrap gap-2 pt-1">
                  <Button variant="dark" onClick={() => setSection("overview")}>
                    Abrir visão geral <ArrowUpRight className="h-4 w-4" />
                  </Button>
                  <Button variant="soft" onClick={() => setSection("finance")}>
                    Ver financeiro
                  </Button>
                </div>

                {/* dots */}
                <div className="flex items-center gap-2 pt-2">
                  <span className="h-2 w-7 rounded-full bg-black/70" />
                  <span className="h-2 w-2 rounded-full bg-black/25" />
                  <span className="h-2 w-2 rounded-full bg-black/25" />
                  <span className="h-2 w-2 rounded-full bg-black/25" />
                </div>
              </div>

              {/* preview card */}
              <div className="relative">
                <GlassCard className="p-3">
                  <div className="rounded-[24px] bg-white/70 p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-display text-sm font-black text-[color:var(--ink)]">
                        Status rápido
                      </div>
                      <div className="text-[11px] font-bold text-[color:var(--muted)]">Preview</div>
                    </div>

                    <div className="mt-3 grid gap-2">
                      <div className="rounded-2xl bg-black/5 p-3">
                        <Skeleton className="h-4 w-[70%]" />
                        <Skeleton className="mt-2 h-4 w-[48%]" />
                      </div>
                      <div className="rounded-2xl bg-black/5 p-3">
                        <Skeleton className="h-4 w-[62%]" />
                        <Skeleton className="mt-2 h-4 w-[40%]" />
                      </div>
                    </div>

                    <div className="mt-3 grid grid-cols-3 gap-2">
                      <div className="h-16 rounded-2xl bg-[rgba(194,65,12,0.12)]" />
                      <div className="h-16 rounded-2xl bg-black/5" />
                      <div className="h-16 rounded-2xl bg-black/5" />
                    </div>
                  </div>
                </GlassCard>
              </div>
            </div>
          </div>
        </section>
      ) : null}

      {/* KPIs (aparece em todas as seções, padrão vivo) */}
      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4" data-stagger>
        {kpis.map((k) => (
          <KpiCard
            key={k.label}
            label={k.label}
            value={k.value}
            icon={k.icon}
            hint={k.hint}
            tone={k.tone}
          />
        ))}
      </section>

      {/* CONTEÚDO por seção */}
      {section === "overview" ? (
        <section className="grid gap-3 lg:grid-cols-[1.2fr_0.8fr]" data-stagger>

    {/* ESQUERDA: Próximas entregas + gráfico */}
    <div className="grid gap-3">
      <GlassCard className="p-4">
        <div className="flex items-center justify-between gap-2">
          <div>
            <div className="font-display text-sm font-black text-[color:var(--ink)]">
              Próximas entregas
            </div>
            <div className="text-xs font-semibold text-[color:var(--muted)]">
              Vai puxar pedidos em andamento
            </div>
          </div>
          <Badge tone="brand">Em breve</Badge>
        </div>

        <div className="mt-4 space-y-2">
          {Array.from({ length: 3 }).map((_, i) => (
            <div
              key={i}
              className="grid grid-cols-[1fr_auto] gap-3 rounded-2xl bg-black/5 p-3"
            >
              <Skeleton className="h-4 w-[68%]" />
              <Skeleton className="h-4 w-20" />
            </div>
          ))}
        </div>
      </GlassCard>

      {/* ✅ GRÁFICO COMPACTO */}
      <WaveMiniCard
        title="Evolução"
        subtitle="Receita mensal (placeholder)"
        points={chartPoints}
        accent="brand"
      />
    </div>

    {/* DIREITA: pagamentos/recebimentos (mantém) */}
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
      <GlassCard className="p-4">
        <div className="font-display text-sm font-black text-[color:var(--ink)]">
          Pagamentos da semana
        </div>
        <div className="mt-3 rounded-2xl bg-black/5 p-3">
          <Skeleton className="h-24 w-full" />
        </div>
      </GlassCard>

      <GlassCard className="p-4">
        <div className="font-display text-sm font-black text-[color:var(--ink)]">
          Recebimentos da semana
        </div>
        <div className="mt-3 rounded-2xl bg-black/5 p-3">
          <Skeleton className="h-24 w-full" />
        </div>
      </GlassCard>
    </div>
  </section>
      ) : null}

      {section === "finance" ? (
        <section className="space-y-3" data-stagger>
          {/* abas do legado */}
          <Tabs items={financeTabs} value={financeTab} onChange={(k) => setFinanceTab(k as FinanceTab)} />

          {financeTab === "receber" ? (
            <DataTable
              title="Recebíveis"
              subtitle="Baseado em /api/finance/receivables/month"
              rows={recvRows}
              rowKey={(r) => r.id}
              columns={[
                { header: "Vencimento", cell: (r) => isoToBR(r.dueDate) },
                { header: "Cliente", cell: (r) => r.client },
                { header: "Descrição", cell: (r) => r.desc },
                {
                  header: "Valor",
                  className: "text-right font-extrabold",
                  cell: (r) => moneyBRLFromCents(r.amountCents),
                },
                {
                  header: "Status",
                  cell: (r) =>
                    r.status === "PAGO" ? (
                      <StatusPill tone="success" label="Pago" />
                    ) : (
                      <StatusPill tone="warning" label="Aberto" />
                    ),
                },
              ]}
            />
          ) : financeTab === "pagar" ? (
            <DataTable
              title="Pagáveis"
              subtitle="Baseado em /api/finance/payables/month"
              rows={payRows}
              rowKey={(r) => r.id}
              columns={[
                { header: "Vencimento", cell: (r) => isoToBR(r.dueDate) },
                { header: "Fornecedor", cell: (r) => r.supplier },
                { header: "Descrição", cell: (r) => r.desc },
                {
                  header: "Valor",
                  className: "text-right font-extrabold",
                  cell: (r) => moneyBRLFromCents(r.amountCents),
                },
                {
                  header: "Status",
                  cell: (r) =>
                    r.status === "PAGO" ? (
                      <StatusPill tone="success" label="Pago" />
                    ) : (
                      <StatusPill tone="warning" label="Aberto" />
                    ),
                },
              ]}
            />
          ) : (
            <GlassCard className="p-5">
              <div className="font-display text-sm font-black text-[color:var(--ink)]">
                {financeTabs.find((t) => t.key === financeTab)?.label}
              </div>
              <div className="mt-2 text-sm font-semibold text-[color:var(--muted)]">
                Placeholder do layout final. No M5 ligamos: overview/plus/dfc/dre/projections e cálculos reais.
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                <KpiCard label="Entradas" value={moneyBRLFromCents(0)} icon={ArrowUpCircle} hint="placeholder" tone="success" />
                <KpiCard label="Saídas" value={moneyBRLFromCents(0)} icon={ArrowDownCircle} hint="placeholder" tone="danger" />
                <KpiCard label="Relatório DRE" value="—" icon={FileText} hint="placeholder" tone="brand" />
                <KpiCard label="Fluxo projetado" value="—" icon={TrendingUp} hint="placeholder" tone="neutral" />
              </div>
            </GlassCard>
          )}
        </section>
      ) : null}

      {section === "sales" ? (
        <GlassCard className="p-5" data-stagger>
          <div className="font-display text-sm font-black text-[color:var(--ink)]">Vendas</div>
          <div className="mt-2 text-sm font-semibold text-[color:var(--muted)]">
            Aqui entra o painel de pedidos + modal completo (já fizemos no M4). No M5 liga endpoints reais.
          </div>
        </GlassCard>
      ) : null}

      {section === "stock" ? (
        <GlassCard className="p-5" data-stagger>
          <div className="font-display text-sm font-black text-[color:var(--ink)]">Estoque</div>
          <div className="mt-2 text-sm font-semibold text-[color:var(--muted)]">
            Aqui entra Catálogo/Movimentações/Quantidade/Histórico (M4 UI + M5 endpoints).
          </div>
          <div className="mt-4">
            <Badge tone="wood">
              <Boxes className="h-3.5 w-3.5" /> Estoque premium
            </Badge>
          </div>
        </GlassCard>
      ) : null}
    </div>
  );
}