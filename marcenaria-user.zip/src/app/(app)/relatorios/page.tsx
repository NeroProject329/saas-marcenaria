import GlassCard from "@/components/ui/GlassCard";
import PageHeader from "@/components/layout/PageHeader";

export default function RelatoriosPage() {
  return (
    <div className="space-y-4">
      <PageHeader
        title="Relatórios"
        subtitle="Export PDF e pacotes (pack / pack.pdf)."
        badge={{ label: "PDF", tone: "ink" }}
      />
      <GlassCard className="p-4">
        <div className="text-sm font-semibold text-[color:var(--muted)]">
          Placeholder premium (M1).
        </div>
      </GlassCard>
    </div>
  );
}