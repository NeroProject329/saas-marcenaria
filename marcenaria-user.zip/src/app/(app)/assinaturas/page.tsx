import GlassCard from "@/components/ui/GlassCard";
import PageHeader from "@/components/layout/PageHeader";

export default function AssinaturasPage() {
  return (
    <div className="space-y-4">
      <PageHeader
        title="Assinaturas"
        subtitle="Planos, limites e status (paridade total no M4/M5)."
        badge={{ label: "M4/M5", tone: "brand" }}
      />
      <GlassCard className="p-4">
        <div className="text-sm font-semibold text-[color:var(--muted)]">
          Placeholder premium (M1).
        </div>
      </GlassCard>
    </div>
  );
}