import GlassCard from "@/components/ui/GlassCard";
import PageHeader from "@/components/layout/PageHeader";

export default function OrcamentosPage() {
  return (
    <div className="space-y-4">
      <PageHeader
        title="Orçamentos"
        subtitle="Cálculo + gerar PDF com breakdown (UI completa no M4, dados reais no M5)."
        badge={{ label: "PDF", tone: "brand" }}
      />
      <GlassCard className="p-4">
        <div className="text-sm font-semibold text-[color:var(--muted)]">
          Placeholder premium (M1).
        </div>
      </GlassCard>
    </div>
  );
}