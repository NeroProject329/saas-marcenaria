import GlassCard from "@/components/ui/GlassCard";
import PageHeader from "@/components/layout/PageHeader";

export default function ConfiguracoesPage() {
  return (
    <div className="space-y-4">
      <PageHeader
        title="Configurações"
        subtitle="Preferências do sistema e conta (auth real entra no M3)."
        badge={{ label: "M3", tone: "brand" }}
      />
      <GlassCard className="p-4">
        <div className="text-sm font-semibold text-[color:var(--muted)]">
          Placeholder premium (M1).
        </div>
      </GlassCard>
    </div>
  );
}