"use client";

import { useMemo, useState } from "react";
import { Plus, ArrowDownCircle, ArrowUpCircle, Tags, Wallet } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import Tabs from "@/components/ui/Tabs";
import Toolbar from "@/components/ui/Toolbar";
import Input from "@/components/ui/Input";
import Select from "@/components/ui/Select";
import Button from "@/components/ui/Button";
import KpiCard from "@/components/ui/KpiCard";
import DataTable from "@/components/ui/DataTable";
import Modal from "@/components/ui/Modal";
import StatusPill from "@/components/ui/StatusPill";
import { FinanceCategory, FinanceTransaction, Payable, Receivable } from "@/lib/types";
import { moneyBRLFromCents, isoToBR, isoToDateInput, parseBRLToCents, dateInputToISO, uid } from "@/lib/format";

export default function FinanceiroPage() {
  const tabs = useMemo(
    () => [
      { key: "cashflow", label: "Fluxo" },
      { key: "receivables", label: "Recebimentos" },
      { key: "payables", label: "Pagamentos" },
      { key: "transactions", label: "Extrato" },
    ],
    []
  );
  const [tab, setTab] = useState("cashflow");

  const [from, setFrom] = useState(() => {
    const d = new Date();
    d.setDate(1);
    return isoToDateInput(d.toISOString());
  });
  const [to, setTo] = useState(() => {
    const d = new Date();
    d.setMonth(d.getMonth() + 1, 0);
    return isoToDateInput(d.toISOString());
  });

  // mock categories/tx (shape igual legacy)
  const [categories, setCategories] = useState<FinanceCategory[]>(() => [
    { id: "c1", name: "Vendas", type: "IN" },
    { id: "c2", name: "Fornecedores", type: "OUT" },
    { id: "c3", name: "Custos fixos", type: "OUT" },
  ]);

  const [txs, setTxs] = useState<FinanceTransaction[]>(() => [
    {
      id: "t1",
      type: "IN",
      name: "Recebimento Pedido #123",
      occurredAt: new Date().toISOString(),
      amountCents: 250000,
      categoryId: "c1",
      categoryName: "Vendas",
      source: "RECEIVABLE",
    },
    {
      id: "t2",
      type: "OUT",
      name: "Pagamento fornecedor (parcela 1/3)",
      occurredAt: new Date().toISOString(),
      amountCents: 80000,
      categoryId: "c2",
      categoryName: "Fornecedores",
      source: "PAYABLE",
    },
    {
      id: "t3",
      type: "OUT",
      name: "Internet",
      occurredAt: new Date().toISOString(),
      amountCents: 12990,
      categoryId: "c3",
      categoryName: "Custos fixos",
      source: "MANUAL",
    },
  ]);

  const receivables = useMemo<Receivable[]>(
    () => [
      { id: "r1", dueDate: new Date().toISOString(), clientName: "Cliente X", description: "Pedido #123", amountCents: 250000, status: "ABERTO" },
      { id: "r2", dueDate: new Date().toISOString(), clientName: "Cliente Y", description: "Pedido #124", amountCents: 180000, status: "PAGO", paidAt: new Date().toISOString() },
    ],
    []
  );

  const payables = useMemo<Payable[]>(
    () => [
      { id: "p1", dueDate: new Date().toISOString(), supplierName: "Fornecedor A", description: "Madeira (NF 123)", amountCents: 80000, status: "ABERTO", installmentLabel: "1/3" },
      { id: "p2", dueDate: new Date().toISOString(), supplierName: "Fornecedor A", description: "Madeira (NF 123)", amountCents: 80000, status: "PAGO", paidAt: new Date().toISOString(), installmentLabel: "2/3" },
    ],
    []
  );

  const totals = useMemo(() => {
    const inCents = txs.filter((t) => t.type === "IN").reduce((a, b) => a + (b.amountCents || 0), 0);
    const outCents = txs.filter((t) => t.type === "OUT").reduce((a, b) => a + (b.amountCents || 0), 0);
    const prev = 0;
    return { prev, inCents, outCents, bal: prev + inCents - outCents };
  }, [txs]);

  // modals
  const [txOpen, setTxOpen] = useState(false);
  const [catOpen, setCatOpen] = useState(false);
  const [txEditing, setTxEditing] = useState<FinanceTransaction | null>(null);

  const [txForm, setTxForm] = useState({
    type: "IN" as "IN" | "OUT",
    name: "",
    date: isoToDateInput(new Date().toISOString()),
    amount: "",
    categoryId: "",
    notes: "",
  });

  const [catForm, setCatForm] = useState({ name: "", type: "" as "" | "IN" | "OUT" });

  function openNewTx(type: "IN" | "OUT") {
    setTxEditing(null);
    setTxForm({
      type,
      name: "",
      date: isoToDateInput(new Date().toISOString()),
      amount: "",
      categoryId: "",
      notes: "",
    });
    setTxOpen(true);
  }

  function saveTx() {
    const occurredAt = dateInputToISO(txForm.date) || new Date().toISOString();
    const amountCents = parseBRLToCents(txForm.amount);
    if (!txForm.name.trim()) return;
    if (amountCents <= 0) return;

    const cat = categories.find((c) => c.id === txForm.categoryId) || null;

    if (!txEditing) {
      setTxs((prev) => [
        {
          id: uid("tx"),
          type: txForm.type,
          name: txForm.name.trim(),
          occurredAt,
          amountCents,
          categoryId: txForm.categoryId || null,
          categoryName: cat?.name || null,
          notes: txForm.notes || null,
          source: "MANUAL",
        },
        ...prev,
      ]);
    } else {
      setTxs((prev) =>
        prev.map((t) =>
          t.id === txEditing.id
            ? {
                ...t,
                name: txForm.name.trim(),
                occurredAt,
                amountCents,
                categoryId: txForm.categoryId || null,
                categoryName: cat?.name || null,
                notes: txForm.notes || null,
              }
            : t
        )
      );
    }

    setTxOpen(false);
    setTxEditing(null);
  }

  function editTx(t: FinanceTransaction) {
    if ((t.source || "MANUAL").toUpperCase() !== "MANUAL") return; // igual legado: só manual edita
    setTxEditing(t);
    setTxForm({
      type: t.type,
      name: t.name,
      date: isoToDateInput(t.occurredAt),
      amount: String((t.amountCents || 0) / 100).replace(".", ","),
      categoryId: t.categoryId || "",
      notes: t.notes || "",
    });
    setTxOpen(true);
  }

  function delTx(t: FinanceTransaction) {
    if ((t.source || "MANUAL").toUpperCase() !== "MANUAL") return;
    setTxs((prev) => prev.filter((x) => x.id !== t.id));
  }

  function saveCategory() {
    if (!catForm.name.trim()) return;
    setCategories((prev) => [
      { id: uid("cat"), name: catForm.name.trim(), type: catForm.type || null },
      ...prev,
    ]);
    setCatForm({ name: "", type: "" });
    setCatOpen(false);
  }

  return (
    <div className="space-y-4">
      <PageHeader
        title="Financeiro"
        subtitle="Fluxo de caixa, recebimentos, pagamentos e extrato (UI pronta — M5 liga endpoints)."
        badge={{ label: "M4", tone: "brand" }}
        right={<Tabs items={tabs} value={tab} onChange={setTab} />}
      />

      <Toolbar
        left={
          <>
            <div className="w-[160px]">
              <Input value={from} onChange={(e) => setFrom(e.target.value)} placeholder="YYYY-MM-DD" />
            </div>
            <div className="w-[160px]">
              <Input value={to} onChange={(e) => setTo(e.target.value)} placeholder="YYYY-MM-DD" />
            </div>
          </>
        }
        right={
          tab === "transactions" ? (
            <>
              <Button variant="soft" onClick={() => setCatOpen(true)}>
                <Tags className="h-4 w-4" /> Categoria
              </Button>
              <Button variant="soft" onClick={() => openNewTx("OUT")}>
                <ArrowDownCircle className="h-4 w-4" /> Saída
              </Button>
              <Button variant="dark" onClick={() => openNewTx("IN")}>
                <ArrowUpCircle className="h-4 w-4" /> Entrada
              </Button>
            </>
          ) : (
            <Button variant="soft">
              <Plus className="h-4 w-4" /> Ação
            </Button>
          )
        }
      />

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard label="Saldo anterior" value={moneyBRLFromCents(totals.prev)} icon={ArrowUpCircle} hint="Virada do mês" />
        <KpiCard label="Entradas" value={moneyBRLFromCents(totals.inCents)} icon={ArrowUpCircle} hint="Recebimentos + entradas" />
        <KpiCard label="Saídas" value={moneyBRLFromCents(totals.outCents)} icon={ArrowDownCircle} hint="Pagamentos + saídas" />
        <KpiCard label="Saldo do mês" value={moneyBRLFromCents(totals.bal)} icon={Wallet} hint="Anterior + Entradas - Saídas" />
      </section>

      {tab === "cashflow" ? (
        <DataTable
          title="Fluxo (placeholder)"
          subtitle={`De ${from} até ${to} • basis=due (igual legado)`}
          rows={[
            { id: "1", day: "Semana 1", inCents: 250000, outCents: 80000 },
            { id: "2", day: "Semana 2", inCents: 180000, outCents: 12990 },
          ]}
          rowKey={(r) => r.id}
          columns={[
            { header: "Período", cell: (r) => r.day },
            { header: "Entradas", className: "text-right font-extrabold", cell: (r) => moneyBRLFromCents(r.inCents) },
            { header: "Saídas", className: "text-right font-extrabold", cell: (r) => moneyBRLFromCents(r.outCents) },
          ]}
        />
      ) : null}

      {tab === "receivables" ? (
        <DataTable
          title="Recebimentos"
          subtitle="Shape igual /api/finance/receivables/month"
          rows={receivables}
          rowKey={(r) => r.id}
          columns={[
            { header: "Vencimento", cell: (r) => isoToBR(r.dueDate) },
            { header: "Cliente", cell: (r) => r.clientName },
            { header: "Descrição", cell: (r) => r.description },
            { header: "Valor", className: "text-right font-extrabold", cell: (r) => moneyBRLFromCents(r.amountCents) },
            {
              header: "Status",
              cell: (r) =>
                r.status === "PAGO" ? <StatusPill tone="success" label="Pago" /> : <StatusPill tone="warning" label="Aberto" />,
            },
          ]}
        />
      ) : null}

      {tab === "payables" ? (
        <DataTable
          title="Pagamentos"
          subtitle="Shape igual /api/finance/payables/month (parcelas)"
          rows={payables}
          rowKey={(r) => r.id}
          columns={[
            { header: "Vencimento", cell: (r) => isoToBR(r.dueDate) },
            { header: "Fornecedor", cell: (r) => r.supplierName },
            { header: "Descrição", cell: (r) => r.description },
            { header: "Parcela", cell: (r) => r.installmentLabel || "—" },
            { header: "Valor", className: "text-right font-extrabold", cell: (r) => moneyBRLFromCents(r.amountCents) },
            {
              header: "Status",
              cell: (r) =>
                r.status === "PAGO" ? <StatusPill tone="success" label="Pago" /> : <StatusPill tone="warning" label="Aberto" />,
            },
          ]}
        />
      ) : null}

      {tab === "transactions" ? (
        <DataTable
          title="Extrato"
          subtitle="Somente MANUAL é editável (igual legado)."
          rows={txs}
          rowKey={(r) => r.id}
          right={<div className="text-xs font-semibold text-[color:var(--muted)]">Categorias: {categories.length}</div>}
          columns={[
            { header: "Data", cell: (r) => isoToBR(r.occurredAt) },
            { header: "Tipo", cell: (r) => (r.type === "IN" ? <StatusPill tone="success" label="Entrada" /> : <StatusPill tone="danger" label="Saída" />) },
            { header: "Categoria", cell: (r) => r.categoryName || "—" },
            { header: "Nome", cell: (r) => r.name },
            {
              header: "Valor",
              className: "text-right font-extrabold",
              cell: (r) => moneyBRLFromCents(r.amountCents),
            },
            {
              header: "Ações",
              className: "text-right",
              cell: (r) => (
                <div className="flex justify-end gap-2">
                  <Button variant="ghost" onClick={() => editTx(r)} disabled={(r.source || "MANUAL").toUpperCase() !== "MANUAL"}>
                    Editar
                  </Button>
                  <Button variant="ghost" onClick={() => delTx(r)} disabled={(r.source || "MANUAL").toUpperCase() !== "MANUAL"}>
                    Excluir
                  </Button>
                </div>
              ),
            },
          ]}
        />
      ) : null}

      {/* MODAL TX */}
      <Modal
        open={txOpen}
        title={txEditing ? "Editar lançamento" : "Novo lançamento"}
        subtitle="Lançamento MANUAL (paridade com legado)."
        onClose={() => setTxOpen(false)}
        footer={
          <div className="flex flex-wrap justify-end gap-2">
            <Button variant="soft" onClick={() => setTxOpen(false)}>Cancelar</Button>
            <Button variant="dark" onClick={saveTx}>Salvar</Button>
          </div>
        }
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Tipo</div>
            <Select value={txForm.type} onChange={(e) => setTxForm((p) => ({ ...p, type: e.target.value as any }))}>
              <option value="IN">Entrada</option>
              <option value="OUT">Saída</option>
            </Select>
          </div>

          <div>
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Data</div>
            <Input value={txForm.date} onChange={(e) => setTxForm((p) => ({ ...p, date: e.target.value }))} />
          </div>

          <div className="sm:col-span-2">
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Nome</div>
            <Input value={txForm.name} onChange={(e) => setTxForm((p) => ({ ...p, name: e.target.value }))} />
          </div>

          <div>
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Valor (R$)</div>
            <Input value={txForm.amount} onChange={(e) => setTxForm((p) => ({ ...p, amount: e.target.value }))} placeholder="120,50" />
          </div>

          <div>
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Categoria</div>
            <Select value={txForm.categoryId} onChange={(e) => setTxForm((p) => ({ ...p, categoryId: e.target.value }))}>
              <option value="">Sem categoria</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
          </div>

          <div className="sm:col-span-2">
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Observações</div>
            <textarea
              className="pill min-h-[90px] w-full px-3 py-2 text-sm font-semibold text-[color:var(--ink)] outline-none"
              value={txForm.notes}
              onChange={(e) => setTxForm((p) => ({ ...p, notes: e.target.value }))}
            />
          </div>
        </div>
      </Modal>

      {/* MODAL CAT */}
      <Modal
        open={catOpen}
        title="Nova categoria"
        subtitle="Paridade com /api/finance/categories"
        onClose={() => setCatOpen(false)}
        maxWidth="max-w-[640px]"
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="soft" onClick={() => setCatOpen(false)}>Cancelar</Button>
            <Button variant="dark" onClick={saveCategory}>Salvar</Button>
          </div>
        }
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Nome</div>
            <Input value={catForm.name} onChange={(e) => setCatForm((p) => ({ ...p, name: e.target.value }))} />
          </div>
          <div>
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Tipo</div>
            <Select value={catForm.type} onChange={(e) => setCatForm((p) => ({ ...p, type: e.target.value as any }))}>
              <option value="">Sem</option>
              <option value="IN">Entrada</option>
              <option value="OUT">Saída</option>
            </Select>
          </div>
        </div>
      </Modal>
    </div>
  );
}