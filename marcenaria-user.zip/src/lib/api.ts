import { API_URL } from "./env";
import { getToken, clearToken } from "./auth";

export class ApiError extends Error {
  status: number;
  data: any;

  constructor(message: string, status: number, data?: any) {
    super(message);
    this.status = status;
    this.data = data;
  }
}

export async function apiFetch<T>(
  path: string,
  opts: RequestInit & { json?: any; auth?: boolean } = {}
): Promise<T> {
  const url = path.startsWith("http")
    ? path
    : `${API_URL}${path.startsWith("/") ? "" : "/"}${path}`;

  const headers = new Headers(opts.headers || {});
  const isJson = opts.json !== undefined;

  if (isJson) headers.set("Content-Type", "application/json");

  const auth = opts.auth ?? true;
  if (auth) {
    const token = getToken();
    if (token) headers.set("Authorization", `Bearer ${token}`);
  }

  const res = await fetch(url, {
    ...opts,
    headers,
    body: isJson ? JSON.stringify(opts.json) : opts.body,
  });

  const contentType = res.headers.get("content-type") || "";
  const data = contentType.includes("application/json")
    ? await res.json().catch(() => null)
    : await res.text().catch(() => null);

  if (!res.ok) {
    if (res.status === 401 && typeof window !== "undefined") {
      clearToken();
      window.dispatchEvent(new CustomEvent("auth:logout"));
    }
    throw new ApiError(data?.message || "Erro na requisição.", res.status, data);
  }

  return data as T;
}