"use client";

import { useMemo, useState } from "react";
import { Plus, UserPlus } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import Toolbar from "@/components/ui/Toolbar";
import Input from "@/components/ui/Input";
import Select from "@/components/ui/Select";
import Button from "@/components/ui/Button";
import DataTable from "@/components/ui/DataTable";
import Modal from "@/components/ui/Modal";
import StatusPill from "@/components/ui/StatusPill";
import GlassCard from "@/components/ui/GlassCard";
import { Client, Order, OrderItem, OrderInstallment, OrderStatus, PaymentMethod, PaymentMode } from "@/lib/types";
import { clamp, dateInputToISO, isoToBR, isoToDateInput, moneyBRLFromCents, parseBRLToCents, uid } from "@/lib/format";

function itemsSummary(items: OrderItem[]) {
  return items
    .slice(0, 3)
    .map((i) => `${i.quantity}x ${i.name}`)
    .join(" • ") + (items.length > 3 ? ` +${items.length - 3}` : "");
}

function statusTone(s: OrderStatus) {
  const u = String(s).toUpperCase();
  if (u === "ENTREGUE" || u === "PRONTO") return "success";
  if (u === "CANCELADO") return "danger";
  if (u === "EM_PRODUCAO" || u === "PEDIDO" || u === "ORCAMENTO") return "warning";
  return "neutral";
}

export default function VendasPage() {
  // mock clients (shape igual /api/clients)
  const [clients, setClients] = useState<Client[]>(() => [
    { id: "cl1", name: "Cliente X", phone: "1199999-1111", type: "CLIENTE", email: "x@email.com" },
    { id: "cl2", name: "Cliente Y", phone: "1199999-2222", type: "CLIENTE", email: "y@email.com" },
  ]);

  const [orders, setOrders] = useState<Order[]>(() => [
    {
      id: "o1",
      clientId: "cl1",
      clientName: "Cliente X",
      status: "EM_PRODUCAO",
      createdAt: new Date().toISOString(),
      expectedDeliveryAt: new Date(Date.now() + 7 * 864e5).toISOString(),
      paymentMode: "PARCELADO",
      paymentMethod: "CARTAO",
      installmentsCount: 3,
      firstDueDate: new Date(Date.now() + 30 * 864e5).toISOString(),
      paidNow: false,
      subtotalCents: 250000,
      discountCents: 0,
      totalCents: 250000,
      items: [
        { id: "i1", name: "Armário planejado", description: null, quantity: 1, unitPriceCents: 250000, totalCents: 250000 },
      ],
      installments: [
        { id: "p1", dueDate: new Date(Date.now() + 30 * 864e5).toISOString(), amountCents: 83333 },
        { id: "p2", dueDate: new Date(Date.now() + 60 * 864e5).toISOString(), amountCents: 83333 },
        { id: "p3", dueDate: new Date(Date.now() + 90 * 864e5).toISOString(), amountCents: 83334 },
      ],
    },
  ]);

  // filtros
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("ALL");

  const filtered = useMemo(() => {
    const qq = q.trim().toLowerCase();
    return orders.filter((o) => {
      if (status !== "ALL" && o.status !== status) return false;
      if (!qq) return true;
      const hay = `${o.clientName || ""} ${o.status} ${itemsSummary(o.items)}`.toLowerCase();
      return hay.includes(qq);
    });
  }, [orders, q, status]);

  // modal pedido
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Order | null>(null);

  const [form, setForm] = useState({
    clientId: "",
    status: "PEDIDO" as OrderStatus,
    expectedDeliveryAt: isoToDateInput(new Date(Date.now() + 7 * 864e5).toISOString()),
    paymentMode: "AVISTA" as PaymentMode,
    paymentMethod: "PIX" as PaymentMethod,
    paidNow: false,
    installmentsCount: 2,
    firstDueDate: isoToDateInput(new Date(Date.now() + 30 * 864e5).toISOString()),
  });

  const [items, setItems] = useState<Array<{ id: string; description: string; quantity: number; unit: string }>>([
    { id: uid("it"), description: "", quantity: 1, unit: "" },
  ]);

  const [installments, setInstallments] = useState<Array<{ id: string; dueDate: string; amount: string }>>([]);

  // modal cliente rápido
  const [clientOpen, setClientOpen] = useState(false);
  const [clientForm, setClientForm] = useState({ name: "", phone: "", email: "" });

  const totalCents = useMemo(() => {
    return items.reduce((acc, it) => acc + it.quantity * parseBRLToCents(it.unit), 0);
  }, [items]);

  function openNew() {
    setEditing(null);
    setForm({
      clientId: clients[0]?.id || "",
      status: "PEDIDO",
      expectedDeliveryAt: isoToDateInput(new Date(Date.now() + 7 * 864e5).toISOString()),
      paymentMode: "AVISTA",
      paymentMethod: "PIX",
      paidNow: false,
      installmentsCount: 2,
      firstDueDate: isoToDateInput(new Date(Date.now() + 30 * 864e5).toISOString()),
    });
    setItems([{ id: uid("it"), description: "", quantity: 1, unit: "" }]);
    setInstallments([]);
    setOpen(true);
  }

  function openEdit(o: Order) {
    setEditing(o);
    setForm({
      clientId: o.clientId,
      status: o.status,
      expectedDeliveryAt: isoToDateInput(o.expectedDeliveryAt || ""),
      paymentMode: (o.paymentMode || "AVISTA") as PaymentMode,
      paymentMethod: (o.paymentMethod || "PIX") as PaymentMethod,
      paidNow: !!o.paidNow,
      installmentsCount: o.installmentsCount || 2,
      firstDueDate: isoToDateInput(o.firstDueDate || ""),
    });

    setItems(
      o.items.map((x) => ({
        id: x.id,
        description: x.name,
        quantity: x.quantity,
        unit: String((x.unitPriceCents || 0) / 100).replace(".", ","),
      }))
    );

    setInstallments(
      (o.installments || []).map((p) => ({
        id: p.id,
        dueDate: isoToDateInput(p.dueDate),
        amount: String((p.amountCents || 0) / 100).replace(".", ","),
      }))
    );

    setOpen(true);
  }

  function addItem() {
    setItems((prev) => [...prev, { id: uid("it"), description: "", quantity: 1, unit: "" }]);
  }

  function genInstallments() {
    const count = clamp(Number(form.installmentsCount || 2), 2, 48);
    const first = form.firstDueDate || isoToDateInput(new Date(Date.now() + 30 * 864e5).toISOString());
    const base = new Date(first + "T12:00:00.000Z");
    const total = totalCents;

    const each = Math.floor(total / count);
    const rest = total - each * count;

    const arr = Array.from({ length: count }).map((_, i) => {
      const d = new Date(base);
      d.setUTCMonth(d.getUTCMonth() + i);
      const cents = each + (i === count - 1 ? rest : 0);
      return {
        id: uid("parc"),
        dueDate: isoToDateInput(d.toISOString()),
        amount: String((cents / 100).toFixed(2)).replace(".", ","),
      };
    });

    setInstallments(arr);
  }

  function saveOrder() {
    if (!form.clientId) return;
    if (!items.length) return;

    if (items.some((it) => !it.description.trim() || it.quantity <= 0)) return;

    const client = clients.find((c) => c.id === form.clientId);
    const expectedDeliveryAt = dateInputToISO(form.expectedDeliveryAt || "") || null;

    const mappedItems: OrderItem[] = items.map((it) => {
      const qty = Math.max(1, Number(it.quantity || 1));
      const unitCents = parseBRLToCents(it.unit);
      return {
        id: it.id,
        name: it.description.trim(),
        description: null,
        quantity: qty,
        unitPriceCents: unitCents,
        totalCents: qty * unitCents,
      };
    });

    let mappedInstallments: OrderInstallment[] | undefined = undefined;

    if (String(form.paymentMode).toUpperCase() === "PARCELADO") {
      const count = clamp(Number(form.installmentsCount || 2), 2, 48);
      if (!form.firstDueDate) return;
      if (installments.length !== count) return;

      const sum = installments.reduce((acc, p) => acc + parseBRLToCents(p.amount), 0);
      if (sum !== totalCents) return;

      mappedInstallments = installments.map((p) => ({
        id: p.id,
        dueDate: dateInputToISO(p.dueDate) || new Date().toISOString(),
        amountCents: parseBRLToCents(p.amount),
      }));
    }

    const payload: Order = {
      id: editing?.id || uid("order"),
      clientId: form.clientId,
      clientName: client?.name || "—",
      status: form.status,
      createdAt: editing?.createdAt || new Date().toISOString(),
      expectedDeliveryAt,
      paymentMode: form.paymentMode,
      paymentMethod: form.paymentMethod,
      installmentsCount: form.installmentsCount,
      firstDueDate: dateInputToISO(form.firstDueDate) || null,
      paidNow: form.paidNow,
      subtotalCents: totalCents,
      discountCents: 0,
      totalCents: totalCents,
      items: mappedItems,
      installments: mappedInstallments,
    };

    setOrders((prev) => {
      const exists = prev.some((x) => x.id === payload.id);
      return exists ? prev.map((x) => (x.id === payload.id ? payload : x)) : [payload, ...prev];
    });

    setOpen(false);
    setEditing(null);
  }

  function cancelOrder(o: Order) {
    setOrders((prev) => prev.map((x) => (x.id === o.id ? { ...x, status: "CANCELADO" } : x)));
  }

  function deleteOrder(o: Order) {
    setOrders((prev) => prev.filter((x) => x.id !== o.id));
  }

  function createClientQuick() {
    if (!clientForm.name.trim() || !clientForm.phone.trim()) return;
    const created: Client = {
      id: uid("cl"),
      name: clientForm.name.trim(),
      phone: clientForm.phone.trim(),
      type: "CLIENTE",
      email: clientForm.email.trim() || null,
    };
    setClients((prev) => [created, ...prev]);
    setForm((p) => ({ ...p, clientId: created.id }));
    setClientForm({ name: "", phone: "", email: "" });
    setClientOpen(false);
  }

  const kpi = useMemo(() => {
    const total = filtered.reduce((a, b) => a + (b.totalCents || 0), 0);
    return { count: filtered.length, totalCents: total };
  }, [filtered]);

  return (
    <div className="space-y-4">
      <PageHeader
        title="Vendas"
        subtitle="Pedidos + modal completo + parcelas + cadastro rápido de cliente (paridade com legado)."
        badge={{ label: "M4", tone: "brand" }}
      />

      <Toolbar
        left={
          <>
            <div className="w-[260px] max-w-full">
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar pedido/cliente..." />
            </div>
            <div className="w-[200px] max-w-full">
              <Select value={status} onChange={(e) => setStatus(e.target.value)}>
                <option value="ALL">Todos status</option>
                <option value="ORCAMENTO">Orçamento</option>
                <option value="PEDIDO">Pedido</option>
                <option value="EM_PRODUCAO">Em produção</option>
                <option value="PRONTO">Pronto</option>
                <option value="ENTREGUE">Entregue</option>
                <option value="CANCELADO">Cancelado</option>
              </Select>
            </div>
          </>
        }
        right={
          <Button variant="dark" onClick={openNew}>
            <Plus className="h-4 w-4" /> Novo pedido
          </Button>
        }
      />

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <GlassCard className="p-4">
          <div className="text-xs font-extrabold text-[color:var(--muted)]">Pedidos</div>
          <div className="mt-2 font-display text-2xl font-black text-[color:var(--ink)]">{kpi.count}</div>
        </GlassCard>
        <GlassCard className="p-4">
          <div className="text-xs font-extrabold text-[color:var(--muted)]">Total</div>
          <div className="mt-2 font-display text-2xl font-black text-[color:var(--ink)]">{moneyBRLFromCents(kpi.totalCents)}</div>
        </GlassCard>
      </section>

      <DataTable
        title="Pedidos"
        subtitle="Shape igual /api/orders (UI pronta)."
        rows={filtered}
        rowKey={(r) => r.id}
        columns={[
          { header: "Criado", cell: (r) => isoToBR(r.createdAt) },
          {
            header: "Status",
            cell: (r) => <StatusPill tone={statusTone(r.status) as any} label={r.status.replaceAll("_", " ")} />,
          },
          { header: "Cliente", cell: (r) => r.clientName || "—" },
          { header: "Entrega", cell: (r) => isoToBR(r.expectedDeliveryAt || null) },
          { header: "Itens", cell: (r) => itemsSummary(r.items) },
          { header: "Total", className: "text-right font-extrabold", cell: (r) => moneyBRLFromCents(r.totalCents) },
          {
            header: "Ações",
            className: "text-right",
            cell: (r) => (
              <div className="flex justify-end gap-2">
                <Button variant="ghost" onClick={() => openEdit(r)}>Editar</Button>
                <Button variant="ghost" onClick={() => cancelOrder(r)}>Cancelar</Button>
                <Button variant="ghost" onClick={() => deleteOrder(r)}>Excluir</Button>
              </div>
            ),
          },
        ]}
      />

      {/* MODAL PEDIDO */}
      <Modal
        open={open}
        title={editing ? "Editar pedido" : "Novo pedido"}
        subtitle="Paridade com payload real do backend (/api/orders e /full)."
        onClose={() => setOpen(false)}
        footer={
          <div className="flex flex-wrap justify-between gap-2">
            <Button variant="soft" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button variant="dark" onClick={saveOrder}>Salvar</Button>
          </div>
        }
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2 flex flex-wrap items-end justify-between gap-2">
            <div className="flex-1 min-w-[220px]">
              <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Cliente</div>
              <Select value={form.clientId} onChange={(e) => setForm((p) => ({ ...p, clientId: e.target.value }))}>
                <option value="">Selecione</option>
                {clients.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} • {c.phone}
                  </option>
                ))}
              </Select>
            </div>

            <Button variant="soft" onClick={() => setClientOpen(true)}>
              <UserPlus className="h-4 w-4" /> Cadastrar cliente
            </Button>
          </div>

          <div>
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Status</div>
            <Select value={form.status} onChange={(e) => setForm((p) => ({ ...p, status: e.target.value as any }))}>
              <option value="ORCAMENTO">Orçamento</option>
              <option value="PEDIDO">Pedido</option>
              <option value="EM_PRODUCAO">Em produção</option>
              <option value="PRONTO">Pronto</option>
              <option value="ENTREGUE">Entregue</option>
              <option value="CANCELADO">Cancelado</option>
            </Select>
          </div>

          <div>
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Entrega prevista</div>
            <Input value={form.expectedDeliveryAt} onChange={(e) => setForm((p) => ({ ...p, expectedDeliveryAt: e.target.value }))} />
          </div>

          <div>
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Pagamento</div>
            <Select value={form.paymentMode} onChange={(e) => setForm((p) => ({ ...p, paymentMode: e.target.value as any }))}>
              <option value="AVISTA">À vista</option>
              <option value="PARCELADO">Parcelado</option>
            </Select>
          </div>

          <div>
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Método</div>
            <Select value={form.paymentMethod} onChange={(e) => setForm((p) => ({ ...p, paymentMethod: e.target.value as any }))}>
              <option value="PIX">PIX</option>
              <option value="DINHEIRO">Dinheiro</option>
              <option value="CARTAO">Cartão</option>
              <option value="BOLETO">Boleto</option>
            </Select>
          </div>

          {form.paymentMode === "PARCELADO" ? (
            <>
              <div>
                <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Parcelas</div>
                <Input
                  value={String(form.installmentsCount)}
                  onChange={(e) => setForm((p) => ({ ...p, installmentsCount: clamp(Number(e.target.value || 2), 2, 48) }))}
                />
              </div>

              <div>
                <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">1º vencimento</div>
                <Input
                  value={form.firstDueDate}
                  onChange={(e) => setForm((p) => ({ ...p, firstDueDate: e.target.value }))}
                />
              </div>

              <div className="sm:col-span-2">
                <Button variant="soft" onClick={genInstallments}>
                  Gerar parcelas
                </Button>

                <div className="mt-3 overflow-auto rounded-2xl border border-[color:var(--line)] bg-white/35">
                  <table className="min-w-[720px] w-full text-sm">
                    <thead className="bg-white/55">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-extrabold text-[color:var(--muted)]">Vencimento</th>
                        <th className="px-4 py-3 text-left text-xs font-extrabold text-[color:var(--muted)]">Valor</th>
                      </tr>
                    </thead>
                    <tbody>
                      {installments.map((p) => (
                        <tr key={p.id} className="border-t border-[color:var(--line)]">
                          <td className="px-4 py-3">
                            <Input
                              value={p.dueDate}
                              onChange={(e) =>
                                setInstallments((prev) => prev.map((x) => (x.id === p.id ? { ...x, dueDate: e.target.value } : x)))
                              }
                            />
                          </td>
                          <td className="px-4 py-3">
                            <Input
                              value={p.amount}
                              onChange={(e) =>
                                setInstallments((prev) => prev.map((x) => (x.id === p.id ? { ...x, amount: e.target.value } : x)))
                              }
                            />
                          </td>
                        </tr>
                      ))}
                      {!installments.length ? (
                        <tr>
                          <td colSpan={2} className="px-4 py-8 text-sm font-semibold text-[color:var(--muted)]">
                            Clique em “Gerar parcelas”.
                          </td>
                        </tr>
                      ) : null}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          ) : null}

          {/* Itens */}
          <div className="sm:col-span-2 mt-2">
            <div className="flex items-center justify-between gap-2">
              <div className="font-display text-sm font-black text-[color:var(--ink)]">Itens</div>
              <Button variant="soft" onClick={addItem}>Adicionar</Button>
            </div>

            <div className="mt-3 overflow-auto rounded-2xl border border-[color:var(--line)] bg-white/35">
              <table className="min-w-[900px] w-full text-sm">
                <thead className="bg-white/55">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-extrabold text-[color:var(--muted)]">Descrição</th>
                    <th className="px-4 py-3 text-left text-xs font-extrabold text-[color:var(--muted)]">Qtd</th>
                    <th className="px-4 py-3 text-left text-xs font-extrabold text-[color:var(--muted)]">Preço unit (R$)</th>
                    <th className="px-4 py-3 text-right text-xs font-extrabold text-[color:var(--muted)]">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((it) => {
                    const rowTotal = it.quantity * parseBRLToCents(it.unit);
                    return (
                      <tr key={it.id} className="border-t border-[color:var(--line)]">
                        <td className="px-4 py-3">
                          <Input
                            value={it.description}
                            onChange={(e) =>
                              setItems((prev) => prev.map((x) => (x.id === it.id ? { ...x, description: e.target.value } : x)))
                            }
                          />
                        </td>
                        <td className="px-4 py-3 w-[140px]">
                          <Input
                            value={String(it.quantity)}
                            onChange={(e) =>
                              setItems((prev) =>
                                prev.map((x) => (x.id === it.id ? { ...x, quantity: clamp(Number(e.target.value || 1), 1, 9999) } : x))
                              )
                            }
                          />
                        </td>
                        <td className="px-4 py-3 w-[200px]">
                          <Input
                            value={it.unit}
                            onChange={(e) => setItems((prev) => prev.map((x) => (x.id === it.id ? { ...x, unit: e.target.value } : x)))}
                          />
                        </td>
                        <td className="px-4 py-3 text-right font-extrabold">
                          {moneyBRLFromCents(rowTotal)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="mt-3 flex justify-end">
              <div className="pill px-4 py-2 text-sm font-extrabold">
                Total: <span className="ml-2 font-display">{moneyBRLFromCents(totalCents)}</span>
              </div>
            </div>
          </div>
        </div>
      </Modal>

      {/* MODAL CLIENTE RÁPIDO */}
      <Modal
        open={clientOpen}
        title="Cadastrar cliente"
        subtitle="Cadastro rápido dentro do pedido (paridade com legado)."
        onClose={() => setClientOpen(false)}
        maxWidth="max-w-[640px]"
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="soft" onClick={() => setClientOpen(false)}>Cancelar</Button>
            <Button variant="dark" onClick={createClientQuick}>Salvar</Button>
          </div>
        }
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Nome</div>
            <Input value={clientForm.name} onChange={(e) => setClientForm((p) => ({ ...p, name: e.target.value }))} />
          </div>
          <div>
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">Telefone</div>
            <Input value={clientForm.phone} onChange={(e) => setClientForm((p) => ({ ...p, phone: e.target.value }))} />
          </div>
          <div>
            <div className="mb-1 text-xs font-extrabold text-[color:var(--muted)]">E-mail</div>
            <Input value={clientForm.email} onChange={(e) => setClientForm((p) => ({ ...p, email: e.target.value }))} />
          </div>
        </div>
      </Modal>
    </div>
  );
}