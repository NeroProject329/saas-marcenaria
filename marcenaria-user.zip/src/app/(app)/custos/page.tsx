import GlassCard from "@/components/ui/GlassCard";
import PageHeader from "@/components/layout/PageHeader";

export default function CustosPage() {
  return (
    <div className="space-y-4">
      <PageHeader
        title="Custos"
        subtitle="Fixos/Variáveis + resumo mensal (dailyFixedCents já alinhado no backend)."
        badge={{ label: "M4/M5", tone: "wood" }}
      />
      <GlassCard className="p-4">
        <div className="text-sm font-semibold text-[color:var(--muted)]">
          Placeholder premium (M1).
        </div>
      </GlassCard>
    </div>
  );
}